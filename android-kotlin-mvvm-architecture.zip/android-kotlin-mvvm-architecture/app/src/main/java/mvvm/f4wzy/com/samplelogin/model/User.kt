package mvvm.f4wzy.com.samplelogin.model

data class User(val first_name: String, val last_name: String, val personal_image: String) {
}